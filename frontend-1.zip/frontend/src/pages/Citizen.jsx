function Citizen() {
  return (
    <div style={{ padding: "20px" }}>
      <h2>Citizen Dashboard</h2>
      <p>Work proof view will be added here.</p>
    </div>
  );
}

export default Citizen;