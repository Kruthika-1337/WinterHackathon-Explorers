import { useParams } from "react-router-dom";
import { useEffect, useState } from "react";

function ProjectImages() {
  const { projectId } = useParams();
  const [images, setImages] = useState([]);

  useEffect(() => {
    fetch(`http://localhost:5000/contractor/project/${projectId}/images`)
      .then((res) => res.json())
      .then((data) => setImages(data));
  }, [projectId]);

  return (
    <div style={{ padding: "30px" }}>
      <h2>Project Images</h2>

      {images.length === 0 ? (
        <p>No uploads yet.</p>
      ) : (
        images.map((img) => (
          <div key={img.id} style={{ marginBottom: "20px" }}>
            <img
              src={`https://drive.google.com/thumbnail?id=${img.driveFileId}&sz=w1000`}
              alt=""
              style={{ width: "280px", borderRadius: "8px" }}
            />
            <p>{img.timestamp ? new Date(img.timestamp).toLocaleString() : ""}</p>
            <p>{img.address}</p>
          </div>
        ))
      )}
    </div>
  );
}

export default ProjectImages;
