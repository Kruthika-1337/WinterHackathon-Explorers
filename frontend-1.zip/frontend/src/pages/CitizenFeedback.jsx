import { useParams, useNavigate } from "react-router-dom";
import { useState } from "react";

function CitizenFeedback() {
  const { projectId } = useParams();
  const navigate = useNavigate();

  const [username, setUsername] = useState("");
  const [message, setMessage] = useState("");
  const [type, setType] = useState("feedback");
  const [photo, setPhoto] = useState(null);

  const send = async (e) => {
    e.preventDefault();

    const form = new FormData();
    form.append("username", username);
    form.append("message", message);
    form.append("type", type);
    if (photo) form.append("photo", photo);

    await fetch(`http://localhost:5000/citizen/project/${projectId}/feedback`, {
      method: "POST",
      body: form,
    });

    alert("Sent!");
    navigate("/citizen/dashboard");
  };

  return (
    <div style={{ padding: "30px" }}>
      <h2>Give Feedback / Complaint</h2>

      <form onSubmit={send}>
        <input
          placeholder="Your name"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
        />
        <br /><br />

        <select value={type} onChange={(e) => setType(e.target.value)}>
          <option value="feedback">Feedback</option>
          <option value="complaint">Complaint</option>
        </select>
        <br /><br />

        <textarea
          placeholder="Write your feedback"
          value={message}
          onChange={(e) => setMessage(e.target.value)}
        />
        <br /><br />

        <input type="file" onChange={(e) => setPhoto(e.target.files[0])} />
        <br /><br />

        <button type="submit">Send</button>
      </form>
    </div>
  );
}

export default CitizenFeedback;
