import { useParams, useNavigate } from "react-router-dom";
import { useState } from "react";

function UploadProgress() {
  const { projectId } = useParams();
  const navigate = useNavigate();
  const [photos, setPhotos] = useState([]);
  const [message, setMessage] = useState("");
  const [uploading, setUploading] = useState(false);

  const handleUpload = async (e) => {
    e.preventDefault();

    if (photos.length === 0) {
      alert("Select at least one image!");
      return;
    }

    setUploading(true);

    try {
      for (let photo of photos) {
        const data = new FormData();
        data.append("photo", photo);
        data.append("projectId", projectId);

        await fetch("http://localhost:5000/upload", {
          method: "POST",
          body: data,
        });
      }

      setMessage("Images uploaded!");
      setTimeout(() => navigate("/contractor/dashboard"), 1000);

    } catch {
      setMessage("Upload failed");
    }

    setUploading(false);
  };

  return (
    <div style={{ padding: "30px" }}>
      <h2>Upload Work Images</h2>
      <p>Project: {projectId}</p>

      <form onSubmit={handleUpload}>
        <input
          type="file"
          multiple
          accept="image/*"
          onChange={(e) => setPhotos([...e.target.files])}
        />
        <br /><br />

        <button type="submit" disabled={uploading}>
          {uploading ? "Uploading..." : "Upload"}
        </button>
      </form>

      <p>{message}</p>
    </div>
  );
}

export default UploadProgress;
