import { useNavigate } from "react-router-dom";
import { useEffect, useState } from "react";

function ContractorDashboard() {
  const navigate = useNavigate();
  const [projects, setProjects] = useState([]);
  const [stats, setStats] = useState({});

  const loadProjects = async () => {
    try {
      const res = await fetch("http://localhost:5000/contractor/projects");
      const data = await res.json();
      setProjects(data);

      const statsObj = {};
      for (let p of data) {
        const imgRes = await fetch(
          `http://localhost:5000/contractor/project/${p.id}/images`
        );
        const imgs = await imgRes.json();
        statsObj[p.id] = {
          total: imgs.length,
          last:
            imgs.length > 0
              ? new Date(imgs[imgs.length - 1].timestamp).toLocaleString()
              : "No uploads yet",
        };
      }
      setStats(statsObj);
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    loadProjects();
  }, []);

  const deleteProject = async (id) => {
    if (!window.confirm("Delete this project permanently?")) return;
    await fetch(`http://localhost:5000/contractor/project/${id}`, {
      method: "DELETE",
    });
    setProjects(projects.filter((p) => p.id !== id));
  };

  return (
    <div style={{ padding: "30px" }}>
      <h2>Contractor Dashboard 👷‍♂️</h2>
      <button onClick={() => navigate("/contractor/add-project")}>
        ➕ Add Project
      </button>

      <h3 style={{ marginTop: "20px" }}>Your Projects</h3>

      {projects.length === 0 ? (
        <p>No projects created yet.</p>
      ) : (
        projects.map((p) => (
          <div
            key={p.id}
            style={{
              border: "1px solid #ccc",
              padding: "15px",
              borderRadius: "8px",
              marginBottom: "15px",
            }}
          >
            <strong>{p.description}</strong>
            <br />
            🗓 {p.startDate} → {p.endDate}
            <p>
              📸 {stats[p.id]?.total || 0} uploads<br />
              ⏱ {stats[p.id]?.last || "—"}
            </p>

            <button onClick={() => navigate(`/contractor/project/${p.id}/upload`)}>
              📤 Upload Images
            </button>

            <button
              style={{ marginLeft: "8px" }}
              onClick={() => navigate(`/contractor/project/${p.id}/images`)}
            >
              🖼 View Images
            </button>

            <button
              style={{ marginLeft: "8px" }}
              onClick={() => navigate(`/contractor/project/${p.id}/edit`)}
            >
              ✏ Edit Project
            </button>

            <button
              style={{ marginLeft: "8px" }}
              onClick={() => navigate(`/contractor/project/${p.id}/feedback`)}
            >
              💬 View Feedback
            </button>

            <button
              style={{ marginLeft: "8px", color: "red" }}
              onClick={() => deleteProject(p.id)}
            >
              🗑 Delete
            </button>
          </div>
        ))
      )}
    </div>
  );
}

export default ContractorDashboard;
