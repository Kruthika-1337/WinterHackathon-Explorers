import { useState } from "react";
import { useNavigate } from "react-router-dom";

function CitizenDashboard() {
  const [query, setQuery] = useState("");
  const [projects, setProjects] = useState([]);
  const navigate = useNavigate();

  const search = async () => {
    if (query.trim().split(" ").length < 2) {
      alert("Enter at least two words (ex: Basavanagudi Bangalore)");
      return;
    }

    const res = await fetch(
      `http://localhost:5000/citizen/search?q=${encodeURIComponent(query)}`
    );
    setProjects(await res.json());
  };

  return (
    <div style={{ padding: "30px" }}>
      <h2>Citizen Dashboard 🧑‍🤝‍🧑</h2>

      <input
        type="text"
        value={query}
        placeholder="Search location... (ex: MG Road Bangalore)"
        onChange={(e) => setQuery(e.target.value)}
      />
      <button onClick={search}>Search</button>

      <br /><br />

      {projects.length === 0 ? (
        <p>No results yet.</p>
      ) : (
        <div>
          <h3>Works Found:</h3>
          {projects.map((p) => (
            <div
              key={p.projectId}
              style={{
                border: "1px solid #ccc",
                padding: "12px",
                borderRadius: "8px",
                marginBottom: "12px",
              }}
            >
              <img
                src={p.thumbnail}
                alt="thumb"
                style={{ width: "250px", borderRadius: "6px" }}
              />
              <p><strong>{p.description}</strong></p>
              <p>{p.address}</p>

              <button
                onClick={() =>
                  navigate(`/citizen/project/${p.projectId}`)
                }
              >
                View Progress
              </button>

              <button
                onClick={() =>
                  navigate(`/citizen/project/${p.projectId}/feedback`)
                }
              >
                Feedback
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default CitizenDashboard;
