export default function CitizenAuth() {
  return <h1>Citizen Login / Signup</h1>;
}